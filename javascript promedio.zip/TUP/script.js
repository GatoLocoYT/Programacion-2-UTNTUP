function Prom() {
var PrimTrim = Number(document.getElementById("PrimerT").value);
var SegTrim = Number(document.getElementById("SegundoT").value);
var TercTrim = Number(document.getElementById("TercerT").value);

var promedio = (PrimTrim + SegTrim + TercTrim) / 3;
    alert("El promedio es de: "+ promedio);
    return false;
}