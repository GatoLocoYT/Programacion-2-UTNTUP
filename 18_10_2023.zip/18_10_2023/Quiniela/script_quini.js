document.addEventListener("DOMContentLoaded", function() {

    var generarBtn = document.getElementById("generarBtn");
    var quinielaContainer = document.getElementById("quiniela");


    generarBtn.addEventListener("click", function() {

        quinielaContainer.innerHTML = "";

        for (var i = 0; i < 14; i++) {
            var numeroAleatorio = Math.floor(Math.random() * 99) + 1;

            var numeroDiv = document.createElement("div");
            numeroDiv.className = "numero";
            numeroDiv.textContent = numeroAleatorio;

            quinielaContainer.appendChild(numeroDiv);
        }
    });
});
