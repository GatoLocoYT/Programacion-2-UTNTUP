document.addEventListener("DOMContentLoaded", function() {

    var btnGenerar = document.getElementById("BtnAl");
    var numeroMostrado = document.getElementById("numeroGenerado");


    btnGenerar.addEventListener("click", function() {

        var numeroAleatorio = Math.floor(Math.random() * 99) + 1;

        numeroMostrado.textContent = numeroAleatorio;
    });
});
